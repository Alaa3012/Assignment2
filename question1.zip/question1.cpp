#include <iostream>

using namespace std;

template <class T>
class BinaryTree
{
public:
    struct treeNode
    {
        T value;
        struct treeNode *left;
        struct treeNode *right;
    };
    treeNode *root;
    void addNode(treeNode *&, treeNode *&);
    int subTreeSize(treeNode *);
    void deleteNode(T, treeNode *&);
    void makeDeletion(treeNode *&);
    void inOrderPrint(treeNode *);
    void preOrderPrint(treeNode *);
    void postOrderPrint(treeNode *);
    int treeSize();

public:
    BinaryTree() // Constructor
    {
        root = NULL;
    }
    void addNodeNode(T);
    bool searchNode(T);
    void remove(T);
    void inOrderPrint()
    {
        inOrderPrint(root);
    }
    void preOrderPrint()
    {
        preOrderPrint(root);
    }
    void postOrderPrint()
    {
        postOrderPrint(root);
    }
    int numNodes();
};

template <class T>
void BinaryTree<T>::addNode(treeNode *&nodePtr, treeNode *&newNode)
{
    if (nodePtr == NULL)
    {
        nodePtr = newNode;
    }
    else if (newNode->value < nodePtr->value)
    {
        addNode(nodePtr->left, newNode);
    }
    else
    {
        addNode(nodePtr->right, newNode);
    }
}

template <class T>
void BinaryTree<T>::addNodeNode(T num)
{
    treeNode *newNode = NULL; // Pointer to a new node.
    // Create a new node and store num in it.
    newNode = new treeNode;
    newNode->value = num;
    newNode->left = newNode->right = NULL;
    // addNode the node.
    addNode(root, newNode);
}

//***************************************************
template <class T>
int BinaryTree<T>::subTreeSize(treeNode *nodePtr)
{
    if (nodePtr==NULL){
        return 0;
    }
    return 1 + subTreeSize(nodePtr->left) + subTreeSize(nodePtr->right);
}
template <class T>
int BinaryTree<T>::treeSize()
{
   return subTreeSize(root);
}

template <class T>
void BinaryTree<T>::deleteNode(T num, treeNode *&nodePtr)
{
    if (num < nodePtr->value)
    {
        deleteNode(num, nodePtr->left);
    }
    else if (num > nodePtr->value)
    {
        deleteNode(num, nodePtr->right);
    }
    else
    {
        makeDeletion(nodePtr);
    }
}

template <class T>
void BinaryTree<T>::makeDeletion(treeNode *&nodePtr)
{

    if (nodePtr->right != NULL || nodePtr->left != NULL)
    {
       nodePtr = NULL;
       return;
    }
    cout << "CANNOT DELETE NODE";
}

template <class T>
void BinaryTree<T>::inOrderPrint(treeNode *nodePtr)
{
    if (nodePtr)
    {
        inOrderPrint(nodePtr->left);
        cout << nodePtr->value << " ";
        inOrderPrint(nodePtr->right);
    }
}

template <class T>
void BinaryTree<T>::preOrderPrint(treeNode *nodePtr)
{
    if (nodePtr)
    {
        cout << nodePtr->value << " ";
        preOrderPrint(nodePtr->left);
        preOrderPrint(nodePtr->right);
    }
}

template <class T>
void BinaryTree<T>::postOrderPrint(treeNode *nodePtr)
{
    if (nodePtr)
    {
        postOrderPrint(nodePtr->left);
        postOrderPrint(nodePtr->right);
        cout << nodePtr->value << " ";
    }
}

// main.cpp
#include <iostream>
int main(int argc, char **argv)
{
    BinaryTree<int> tree;

    cout << "\naddNodeing nodes with 20, 5, 8, 3 12, 9, 12, and 16 " << endl;
    ;
    tree.addNodeNode(20);
    tree.addNodeNode(5);
    tree.addNodeNode(8);
    tree.addNodeNode(3);
    tree.addNodeNode(12);
    tree.addNodeNode(9);
    tree.addNodeNode(2);
    tree.addNodeNode(16);

    cout << "\nThe number of nodes in the tree is now " << tree.numNodes() << endl;
    ;

    cout << "\nHere are the values in the tree in-order:" << endl;
    ;
    tree.inOrderPrint();

    tree.deleteNode(8);
    tree.deleteNode(12);

    cout << "\nThe number of nodes in the tree is now " << tree.numNodes() << endl;
    ;

    cout << "\n\nHere are the values in the tree in-order:" << endl;
    ;
    tree.inOrderPrint();

    cout << "\n\nHere are the values in the tree in post order:" << endl;
    ;
    tree.postOrderPrint();

    return 0;
}